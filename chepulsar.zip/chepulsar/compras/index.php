<?php
//incluir el config
include_once("config.php");
//buscar tabla
$result = $dbConn->query("SELECT * FROM compras ORDER BY id DESC");
?>
<html>
<head>
	<title>tabla de compras</title>
	<link rel="stylesheet" type="text/css" href="../articulos/css.css">
</head>

<body>
<div class="contenido">
<div id="menu">
	<ul class="nav">
		<li><a href="../dashboard.php" > dashboard</a></li>
		<li><a href='javascript:self.history.back();'>Regresa</a></li>
		<li><a href="javascript:abrir()">ingresar Compras</a></li>
		<li><a href="../logout.php">Salir</a></li>
	</ul>
</div><br><br><br><br>
<table class="table" border="2">
	<tr>
		<td>Nombre</td>
		<td>Producto</td>
		<td>Precio</td>
		<td>Direccion</td>
		<td>Telefono</td>
		<td>Garantia</td>
		<td>Cantidad</td>
		<td>Actualizar</td>
	</tr>
	<?php
	while($row =$result->fetch(PDO::FETCH_ASSOC)){
		echo "<tr>";
		echo "<td>".$row['nombre']."</td>";
		echo "<td>".$row['producto']."</td>";
		echo "<td>".$row['precio']."</td>";
		echo "<td>".$row['direccion']."</td>";
		echo "<td>".$row['telefono']."</td>";
		echo "<td>".$row['garantia']."</td>";
		echo "<td>".$row['cantidad']."</td>";
		echo "<td><a href=\"edit.php?id=$row[id]\"> Edit</a> | <a href=\"delete.php?id=$row[id]\" onClick=\"return confirm('Deseas elimimar esta fila')\">Borrar</a></td>";
		echo "</tr>";
	}
	?>
	</table>
	<form action="" id="form" method="post">
		<table class="table1">
			<tr>
				<td>Nombre</td>
				<td><input type="text" class="casillano" name="nombre"></td>
			</tr>
			<tr>
				<td>Producto</td>
				<td><input type="text" class="casillano" name="producto"></td>
			</tr>
			<tr>
				<td>Precio</td>
				<td><input type="text"  class="casillano" name="precio"></td>
			</tr>
			<tr>
				<td>Direccion</td>
				<td><input type="text" class="casillano" name="direccion"></td>
			</tr>
			<tr>
				<td>Telefono</td>
				<td><input type="text" class="casillano" name="telefono"></td>
			</tr>
			<tr>
				<td>Garantia</td>
				<td><input type="text" class="casillano" name="garantia"></td>
			</tr>
			<tr>
				<td>Cantidad</td>
				<td><input type="text" class="casillano" name="cantidad"></td>
			</tr>
			<tr>
				<td><input type="submit" class="accion" value="ocultar formulario"></td>
				<td><input type="submit" class="accion" name="Submit" value="Add"></td>
			</tr>
		<table>
	</form>
	<?php
include_once("config.php");
// creador de variables
if (isset($_POST['Submit'])) {
	$nombre = $_POST['nombre'];
	$producto = $_POST['producto'];
	$precio = $_POST['precio'];
	$direccion = $_POST['direccion'];
	$telefono = $_POST['telefono'];
	$garantia = $_POST['garantia'];
	$cantidad = $_POST['cantidad'];
// verificador de variables
	if(empty($nombre) || empty($producto) || empty ($precio) || empty ($direccion) || empty ($telefono) ||empty ($garantia) || empty ($cantidad)){
		if(empty($nombre)){
			echo "<h1>Campo: Nombre esta vacio.</h1>";
		}
		if(empty($producto)){
			echo "<h1>Campo: Producto esta vacio.</h1>";
		}
		if(empty($precio)){
			echo "<h1>Campo: Precio esta vacio.</h1>";
		}
		if(empty($direccion)){
			echo "<h1>Campo: Direccion esta vacio.</h1>";
		}
		if(empty($telefono)){
			echo "<h1>Campo: Telefono esta vacio.</h1>";
		}
		if(empty($garantia)){
			echo "<h1>Campo: Garantia esta vacio.</h1>";
		}
		if(empty($cantidad)){
			echo "<h1>Campo: Cantidad de compra esta vacio.</h1>";
		}		
		echo "<br><a href='javascript:self.history.back();'>Regresa</a>";
	} else {
// insertar variables
		$sql = "INSERT INTO compras (nombre, producto, precio, direccion, telefono, garantia, cantidad) VALUES(:nombre, :producto, :precio, :direccion, :telefono, :garantia, :cantidad)";
		$query = $dbConn->prepare($sql);
		
		$query->bindparam(':nombre', $nombre);
		$query->bindparam(':producto', $producto);
		$query->bindparam(':precio', $precio);
		$query->bindparam(':direccion',$direccion);
		$query->bindparam(':telefono',$telefono);
		$query->bindparam(':garantia', $garantia);
		$query->bindparam(':cantidad', $cantidad);
		$query->execute();
		
		header ("location: index.php");
	}	
	}
?>
<script>
function abrir(){
  document.getElementById("form").style.display="block";
  }
	</script>
	</div>
</body>
</html>