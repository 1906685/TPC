<?php
//incluir el config
include_once("config.php");
//buscar tabla
$result = $dbConn->query("SELECT * FROM ventas ORDER BY id DESC");
?>
<html>
<head>
	<title>tabla de ventas</title>
	<link rel="stylesheet" type="text/css" href="../articulos/css.css">
</head>

<body>
<div class="contenido">
<div id="menu">
  <ul class="nav">
		<li><a href="../dashboard.php" > dashboard</a></li>
		<li><a href='javascript:self.history.back();'>Regresa</a></li>
		<li><a href="javascript:abrir()">ingresar servicios</a></li>
		<li><a href="../logout.php">Salir</a></li>
	</ul>
</div><br><br><br><br>
<table class="table" border="2">
	<tr>
		<td>Cliente</td>
		<td>Empleado</td>
		<td>Producto</td>
		<td>Cantidad</td>
		<td>Precio</td>
		<td>Fecha de venta</td>
		<td>Forma de pago</td>
		<td>Contacto</td>
		<td>Actualizar</td>
	</tr>
	<?php
	while($row =$result->fetch(PDO::FETCH_ASSOC)){
		echo "<tr>";
		echo "<td>".$row['cliente']."</td>";
		echo "<td>".$row['empleado']."</td>";
		echo "<td>".$row['producto']."</td>";
		echo "<td>".$row['cantidad']."</td>";
		echo "<td>".$row['precio']."</td>";
		echo "<td>".$row['s_date']."</td>";
		echo "<td>".$row['f_pago']."</td>";
		echo "<td>".$row['f_pago']."</td>";
		echo "<td><a href=\"edit.php?id=$row[id]\"> Edit</a> | <a href=\"delete.php?id=$row[id]\" onClick=\"return confirm('Deseas elimimar esta fila')\">Borrar</a></td>";
		echo "</tr>";
	}
	?>
	</table>
	<form action="" id="form" method="post">
		<table >
			<tr>
				<td>Cliente</td>
				<td><input type="text" class="casillano" name="cliente"></td>
			</tr>
			<tr>
				<td>Empleado</td>
				<td><input type="text" class="casillano" name="empleado"></td>
			</tr>
			<tr>
				<td>Producto</td>
				<td><input type="text" class="casillano" name="producto"></td>
			</tr>
			<tr>
				<td>Cantidad</td>
				<td><input type="text" class="casillano" name="cantidad"></td>
			</tr>
			<tr>
				<td>Precio</td>
				<td><input type="text" class="casillano" name="precio"></td>
			</tr>
			<tr>
				<td>Fecha de venta</td>
				<td><input type="text" class="casillano" name="s_date"></td>
			</tr>
			<tr>
				<td>Forma de pago</td>
				<td><input type="text" class="casillano" name="f_pago"></td>
			</tr>
			<tr>
				<td>Contacto</td>
				<td><input type="text" class="casillano" name="contacto"></td>
			</tr>
			<tr>
				<td><input type="submit" class="accion" value="ocultar formulario"></td>
				<td><input type="submit" class="accion" name="Submit" value="Add"></td>
			</tr>
		</table>
	</form>
	
	<?php
include_once("config.php");
// creador de variables
if (isset($_POST['Submit'])) {
	$cliente = $_POST['cliente'];
	$empleado = $_POST['empleado'];
	$producto = $_POST['producto'];
	$cantidad = $_POST['cantidad'];
	$precio = $_POST['precio'];
	$s_date = $_POST['s_date'];
	$f_pago = $_POST['f_pago'];
	$contacto = $_POST['contacto'];
// verificador de variables
	if(empty($cliente) || empty($empleado) || empty($producto) || empty ($cantidad) || empty ($precio) || empty ($s_date) ||empty ($f_pago) || empty ($contacto)){
		if(empty($cliente)){
			echo "<h1>Campo : cliente esta vacio.</h1>";
		}
		if(empty($empleado)){
			echo "<h1>Campo: empleado esta vacio.</h1>";
		}		
		if(empty($producto)){
			echo "<h1>Campo: producto esta vacio.</h1>";
		}
		if(empty($cantidad)){
			echo "<h1>Campo: cantidad esta vacio.</h1>";
		}
		if(empty($precio)){
			echo "<h1>Campo: Precio esta vacio.</h1>";
		}
		if(empty($s_date)){
			echo "<h1>Campo: Fecha de venta esta vacio.</h1>";
		}
		if(empty($f_pago)){
			echo "<h1>Campo: Forma de pago esta vacio.</h1>";
		}
		if(empty($contacto)){
			echo "<h1>Campo: Tipo de moto esta vacio.</h1>";
		}
	echo "<br><a href='javascript:self.history.back();'>Regresa</a>";
	} else {
// insertar variables
		$sql = "INSERT INTO ventas (cliente, empleado, producto, cantidad, precio, s_date, f_pago, contacto) VALUES(:cliente, :empleado, :producto, :cantidad, :precio, :s_date, :f_pago, :contacto)";
		$query = $dbConn->prepare($sql);
		
		$query->bindparam(':cliente', $cliente);
		$query->bindparam(':empleado', $empleado);
		$query->bindparam(':producto', $producto);
		$query->bindparam(':cantidad', $cantidad);
		$query->bindparam(':precio', $precio);
		$query->bindparam(':s_date',$s_date);
		$query->bindparam(':f_pago',$f_pago);
		$query->bindparam(':contacto', $contacto);
		$query->execute();
		
		header("location:index.php");
	}	
	}
?>
<script>
function abrir(){
  document.getElementById("form").style.display="block";
  }
	</script>
</div>
</body>
</html>