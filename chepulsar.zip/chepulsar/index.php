 <html>
<head>
	<title>inicio</title>
	<link rel="stylesheet" type="text/css" href="css.css">

</head>
<body class="body1">
	<div align="center"><img src="https://vignette.wikia.nocookie.net/logopedia/images/b/bd/Bienvenidos_%282014%29_%281%29.png/revision/latest/scale-to-width-down/340?cb=20190907004342&path-prefix=es"><br><br><br><br>
<div class="dashopt col-5 col-s-5">
	<a href="login.php">ingresar</a><br>
	<a href="register.php">registrarse</a><br>
</div></div>

</body>
</html>
