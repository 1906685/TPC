<?php
//incluir el config
include_once("config.php");
//buscar tabla
$result = $dbConn->query("SELECT * FROM empleado ORDER BY id DESC");
?>
<html>
<head>
	<title>tabla de empleado</title>
	<link rel="stylesheet" type="text/css" href="../articulos/css.css">
</head>

<body>
<div class="contenido">
<div id="menu">
	<ul class="nav">
		<li><a href="../dashboard.php" > dashboard</a></li>
		<li><a href='javascript:self.history.back();'>Regresa</a></li>
		<li><a href="javascript:abrir()">ingresar Empleados</a></li>
		<li><a href="../logout.php">Salir</a></li>
	</ul>
</div><br><br><br><br>
<table class="table" border="2">
	<tr>
		<td>Nombre</td>
		<td>Contacto</td>
		<td>Numero de documento</td>
		<td>Fecha de contratacion</td>
		<td>Nacionalidad</td>
		<td>Cargo</td>
		<td>Fecha de nacimiento</td>
		<td>EPS</td>
		<td>ARL</td>
		<td>Direccion</td>
		<td>Actualizar</td>
	</tr>
	<?php
	while($row =$result->fetch(PDO::FETCH_ASSOC)){
		echo "<tr>";
		echo "<td>".$row['nombre']."</td>";
		echo "<td>".$row['contacto']."</td>";
		echo "<td>".$row['id_num']."</td>";
		echo "<td>".$row['h_date']."</td>";
		echo "<td>".$row['nacionalidad']."</td>";
		echo "<td>".$row['cargo']."</td>";
		echo "<td>".$row['b_date']."</td>";
		echo "<td>".$row['eps']."</td>";
		echo "<td>".$row['arl']."</td>";
		echo "<td>".$row['direccion']."</td>";
		echo "<td><a href=\"edit.php?id=$row[id]\"> Edit</a> | <a href=\"delete.php?id=$row[id]\" onClick=\"return confirm('Deseas elimimar esta fila')\">Borrar</a></td>";
		echo "</tr>";
	}
	?>
	</table>
	<form action="" id="form" method="post">
		<table >
			<tr>
				<td>Nombre</td>
				<td><input type="text" class="casillano" name="nombre"></td>
			</tr>
			<tr>
				<td>Contacto</td>
				<td><input type="text"class="casillano"  name="contacto"></td>
			</tr>
			<tr>
				<td>Numero de documento</td>
				<td><input type="text"class="casillano"  name="id_num"></td>
			</tr>
			<tr>
				<td>Fecha de contratacion</td>
				<td><input type="text"class="casillano" name="h_date"></td>
			</tr>
			<tr>
				<td>Nacionalidad</td>
				<td><input type="text"class="casillano" name="nacionalidad"></td>
			</tr>
			<tr>
				<td>Cargo</td>
				<td><input type="text" class="casillano" name="cargo"></td>
			</tr>
			<tr>
				<td>Fecha de nacimiento</td>
				<td><input type="text"class="casillano"  name="b_date"></td>
			</tr>
			<tr>
				<td>EPS</td>
				<td><input type="text" class="casillano"  name="eps"></td>
			</tr>
			<tr>
				<td>ARL</td>
				<td><input type="text" class="casillano" name="arl"></td>
			</tr>
			<tr>
				<td>Direccion</td>
				<td><input type="text" class="casillano" name="direccion"></td>
			</tr>
			<tr>
				<td><input type="submit" class="accion" value="ocultar formulario"></td>
				<td><input type="submit" class="accion" name="Submit" value="Add"></td>
			</tr>
		<table>
	</form>
	<?php
include_once("config.php");
// creador de variables
if (isset($_POST['Submit'])) {
	$nombre = $_POST['nombre'];
	$contacto = $_POST['contacto'];
	$id_num = $_POST['id_num'];
	$h_date = $_POST['h_date'];
	$nacionalidad = $_POST['nacionalidad'];
	$cargo = $_POST['cargo'];
	$b_date = $_POST['b_date'];
	$eps = $_POST['eps'];
	$arl = $_POST['arl'];
	$direccion = $_POST['direccion'];
// verificador de variables
	if(empty($nombre) || empty($contacto) || empty ($id_num) || empty ($h_date) || empty ($nacionalidad) ||empty ($cargo) || empty ($b_date) || empty ($eps) || empty ($arl) || empty ($direccion)){
		if(empty($nombre)){
			echo "<h1>Campo: Nombre esta vacio.</h1>";
		}		
		if(empty($contacto)){
			echo "<h1>Campo: Contacto esta vacio.</h1>";
		}
		if(empty($id_num)){
			echo "<h1>Campo: Numero de documento esta vacio.</h1>";
		}
		if(empty($h_date)){
			echo "<h1>Campo: Fecha de contratacion esta vacio.</h1>";
		}
		if(empty($nacionalidad)){
			echo "<h1>Campo: Nacionalidad esta vacio.</h1>";
		}
		if(empty($cargo)){
			echo "<h1>Campo: Cargo esta vacio.</h1>";
		}
		if(empty($b_date)){
			echo "<h1>Campo: Fecha de nacimiento esta vacio.</h1>";
		}
		if(empty($eps)){
			echo "<h1>Campo: EPS de compra esta vacio.</h1>";
		}
		if(empty($arl)){
			echo "<h1>Campo: ARL de venta esta vacio.</h1>";
		}
		if(empty($direccion)){
			echo "<h1>Campo: Direccion esta vacio.</h1>";
		}
		echo "<br><a href='javascript:self.history.back();'>Regresa</a>";
	} else {
// insertar variables
		$sql = "INSERT INTO empleado (nombre, contacto, id_num, h_date, nacionalidad, cargo, b_date, eps, arl, direccion) VALUES(:nombre, :contacto, :id_num, :h_date, :nacionalidad, :cargo, :b_date, :eps, :arl, :direccion)";
		$query = $dbConn->prepare($sql);
		
		$query->bindparam(':nombre', $nombre);
		$query->bindparam(':contacto', $contacto);
		$query->bindparam(':id_num', $id_num);
		$query->bindparam(':h_date', $h_date);
		$query->bindparam(':nacionalidad',$nacionalidad);
		$query->bindparam(':cargo',$cargo);
		$query->bindparam(':b_date', $b_date);
		$query->bindparam(':eps', $eps);
		$query->bindparam(':arl', $arl);
		$query->bindparam(':direccion', $direccion);
		$query->execute();
		
		header("Location: index.php");
	}	
	}
?>
<script>
function abrir(){
  document.getElementById("form").style.display="block";
  }
	</script>
</div>
</body>
</html>