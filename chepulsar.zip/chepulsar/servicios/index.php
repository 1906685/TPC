<?php
//incluir el config
include_once("config.php");
//buscar tabla
$result = $dbConn->query("SELECT * FROM servicios ORDER BY id DESC");
?>
<html>
<head>
	<title>tabla de servicios</title>
	<link rel="stylesheet" type="text/css" href="../articulos/css.css">
</head>

<body>
<div class="contenido">
<div id="menu">
   <ul class="nav">
		<li><a href="../dashboard.php" > dashboard</a></li>
		<li><a href='javascript:self.history.back();'>Regresa</a></li>
		<li><a href="javascript:abrir()">ingresar servicios</a></li>
		<li><a href="../logout.php">Salir</a></li>
	</ul>
</div><br><br><br><br>
<table class="table" border="2">
	<tr>
		<td>Tipo</td>
		<td>Nombre</td>
		<td>Duracion</td>
		<td>Encargado</td>
		<td>Precio</td>
		<td>Equipamiento</td>
		<td>Garantia</td>
		<td>Tipo de moto</td>
		<td>Marca de moto</td>
		<td>Actualizar</td>
	</tr>
	<?php
	while($row =$result->fetch(PDO::FETCH_ASSOC)){
		echo "<tr>";
		echo "<td>".$row['tipo']."</td>";
		echo "<td>".$row['nombre']."</td>";
		echo "<td>".$row['duracion']."</td>";
		echo "<td>".$row['encargado']."</td>";
		echo "<td>".$row['precio']."</td>";
		echo "<td>".$row['equipamiento']."</td>";
		echo "<td>".$row['garantia']."</td>";
		echo "<td>".$row['tip_moto']."</td>";
		echo "<td>".$row['mar_moto']."</td>";
		echo "<td><a href=\"edit.php?id=$row[id]\"> Edit</a> | <a href=\"delete.php?id=$row[id]\" onClick=\"return confirm('Deseas elimimar esta fila')\">Borrar</a></td>";
		echo "</tr>";
	}
	?>
	</table>
	<form action="" id="form" method="post">
		<table >
			<tr>
				<td>Tipo</td>
				<td><input type="text" class="casillano" name="tipo"></td>
			</tr>
			<tr>
				<td>Nombre</td>
				<td><input type="text" class="casillano" name="nombre"></td>
			</tr>
			<tr>
				<td>Duracion</td>
				<td><input type="text" class="casillano" name="duracion"></td>
			</tr>
			<tr>
				<td>Encargado</td>
				<td><input type="text" class="casillano" name="encargado"></td>
			</tr>
			<tr>
				<td>Precio</td>
				<td><input type="text" class="casillano" name="precio"></td>
			</tr>
			<tr>
				<td>Equipamiento</td>
				<td><input type="text" class="casillano" name="equipamiento"></td>
			</tr>
			<tr>
				<td>Garantia</td>
				<td><input type="text" class="casillano" name="garantia"></td>
			</tr>
			<tr>
				<td>Tipo de Moto</td>
				<td><input type="text"class="casillano"  name="tip_moto"></td>
			</tr>
			<tr>
				<td>Marca de moto</td>
				<td><input type="text" class="casillano" name="mar_moto"></td>
			</tr>
			<tr>
				<td><input type="submit" class="accion" value="ocultar formulario"></td>
				<td><input type="submit" class="accion" name="Submit" value="Add"></td>
			</tr>
		<table>
	</form>
	<?php
include_once("config.php");
// creador de variables
if (isset($_POST['Submit'])) {
	$tipo = $_POST['tipo'];
	$nombre = $_POST['nombre'];
	$duracion = $_POST['duracion'];
	$encargado = $_POST['encargado'];
	$precio = $_POST['precio'];
	$equipamiento = $_POST['equipamiento'];
	$garantia = $_POST['garantia'];
	$tip_moto = $_POST['tip_moto'];
	$mar_moto = $_POST['mar_moto'];
// verificador de variables
	if(empty($tipo) || empty($nombre) || empty($duracion) || empty ($encargado) || empty ($precio) || empty ($equipamiento) ||empty ($garantia) || empty ($tip_moto) || empty ($mar_moto)){
		if(empty($tipo)){
			echo "<h1>Campo : Tipo esta vacio.</h1>";
		}
		if(empty($nombre)){
			echo "<h1>Campo: Nombre esta vacio.</h1>";
		}		
		if(empty($duracion)){
			echo "<h1>Campo: Duracion esta vacio.</h1>";
		}
		if(empty($encargado)){
			echo "<h1>Campo: Encargado esta vacio.</h1>";
		}
		if(empty($precio)){
			echo "<h1>Campo: Precio esta vacio.</h1>";
		}
		if(empty($equipamiento)){
			echo "<h1>Campo: Equipamiento esta vacio.</h1>";
		}
		if(empty($garantia)){
			echo "<h1>Campo: Garantia esta vacio.</h1>";
		}
		if(empty($tip_moto)){
			echo "<h1>Campo: Tipo de moto esta vacio.</h1>";
		}
		if(empty($Mar_moto)){
			echo "<h1>Campo: Marca de moto de compra esta vacio.</h1>";
		}		
		echo "<br><a href='javascript:self.history.back();'>Regresa</a>";
	} else {
// insertar variables
		$sql = "INSERT INTO servicios (tipo, nombre, duracion, encargado, precio, equipamiento, garantia, tip_moto, mar_moto) VALUES(:tipo, :nombre, :duracion, :encargado, :precio, :equipamiento, :garantia, :tip_moto, :mar_moto)";
		$query = $dbConn->prepare($sql);
		
		$query->bindparam(':tipo', $tipo);
		$query->bindparam(':nombre', $nombre);
		$query->bindparam(':duracion', $duracion);
		$query->bindparam(':encargado', $encargado);
		$query->bindparam(':precio', $precio);
		$query->bindparam(':equipamiento',$equipamiento);
		$query->bindparam(':garantia',$garantia);
		$query->bindparam(':tip_moto', $tip_moto);
		$query->bindparam(':mar_moto', $mar_moto);
		$query->execute();
		
		header("location:index.php");
		
	}	
	}
?>
<script>
function abrir(){
  document.getElementById("form").style.display="block";
  }
	</script>
</div>
</body>
</html>